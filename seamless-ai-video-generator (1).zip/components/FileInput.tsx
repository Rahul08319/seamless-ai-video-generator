
import React, { useState, useRef, useEffect } from 'react';
import ImageIcon from './icons/ImageIcon';

interface FileInputProps {
  id: string;
  accept: string;
  onFileChange: (file: File | null) => void;
  file: File | null;
  prompt: string;
}

const FileInput: React.FC<FileInputProps> = ({ id, accept, onFileChange, file, prompt }) => {
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (file && accept.startsWith('image/')) {
      const objectUrl = URL.createObjectURL(file);
      setPreview(objectUrl);
      return () => URL.revokeObjectURL(objectUrl);
    } else if (!file) {
      setPreview(null);
    }
  }, [file, accept]);

  const handleDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileChange(e.target.files[0]);
    }
  };

  return (
    <div className="w-full">
      <label
        htmlFor={id}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onClick={handleClick}
        className="cursor-pointer mt-2 flex justify-center w-full h-48 px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md bg-gray-800/50 hover:border-blue-500 transition-colors duration-200"
      >
        <div className="space-y-1 text-center flex flex-col items-center justify-center">
          {preview ? (
            <img src={preview} alt="Preview" className="max-h-32 rounded-md" />
          ) : (
            <ImageIcon className="mx-auto h-12 w-12 text-gray-400" />
          )}
          
          {file ? (
            <p className="text-sm text-gray-300 mt-2">{file.name}</p>
          ) : (
            <>
              <div className="flex text-sm text-gray-400">
                <p className="pl-1">{prompt}</p>
              </div>
              <p className="text-xs text-gray-500">{accept.split(',').join(', ')}</p>
            </>
          )}

        </div>
        <input ref={fileInputRef} id={id} name={id} type="file" className="sr-only" accept={accept} onChange={handleFileChange} />
      </label>
    </div>
  );
};

export default FileInput;
