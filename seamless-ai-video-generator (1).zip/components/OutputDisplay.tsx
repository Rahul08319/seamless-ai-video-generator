
import React from 'react';
import { GenerationResult } from '../types';
import Loader from './Loader';

interface OutputDisplayProps {
  isLoading: boolean;
  result: GenerationResult | null;
  error: string | null;
}

const OutputDisplay: React.FC<OutputDisplayProps> = ({ isLoading, result, error }) => {
  const renderContent = () => {
    if (isLoading) {
      return <Loader message="Generating video concept..." />;
    }

    if (error) {
      return (
        <div className="text-center p-8 bg-red-900/20 rounded-lg">
          <h3 className="text-xl font-bold text-red-400">Generation Failed</h3>
          <p className="mt-2 text-red-300">{error}</p>
        </div>
      );
    }

    if (result) {
      return (
        <div className="animate-fade-in space-y-6">
          <div>
            <h3 className="text-xl font-bold text-blue-400 mb-3 tracking-wide">Generated Keyframe</h3>
            <img src={result.imageUrl} alt="Generated visual concept" className="w-full rounded-lg shadow-2xl shadow-blue-900/20" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-blue-400 mb-3 tracking-wide">Cinematic Description</h3>
            <div className="prose prose-invert prose-sm sm:prose-base max-w-none p-4 bg-gray-800/50 rounded-lg text-gray-300 whitespace-pre-wrap font-mono">
              {result.description}
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="text-center p-8">
        <h3 className="text-2xl font-bold text-gray-400">Your AI Video Director Awaits</h3>
        <p className="mt-2 text-gray-500">Provide an input and click "Generate" to bring your idea to life.</p>
      </div>
    );
  };

  return (
    <div className="bg-gray-900/70 backdrop-blur-sm rounded-lg shadow-lg p-6 min-h-[300px] flex flex-col justify-center border border-gray-700">
      {renderContent()}
    </div>
  );
};

export default OutputDisplay;
