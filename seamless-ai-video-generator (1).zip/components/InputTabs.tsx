
import React from 'react';
import { InputType } from '../types';
import { TABS } from '../constants';

interface InputTabsProps {
  activeTab: InputType;
  onTabChange: (tab: InputType) => void;
}

const InputTabs: React.FC<InputTabsProps> = ({ activeTab, onTabChange }) => {
  return (
    <div className="flex items-center space-x-2 sm:space-x-1 p-1 bg-gray-800/50 rounded-lg backdrop-blur-sm">
      {TABS.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`w-full flex items-center justify-center space-x-2 px-3 py-2 text-sm font-medium rounded-md transition-all duration-200 ease-in-out focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-opacity-75
            ${
              activeTab === tab.id
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-300 hover:bg-gray-700/60'
            }`}
        >
          <span className="w-5 h-5">{tab.icon}</span>
          <span className="hidden sm:inline">{tab.label}</span>
        </button>
      ))}
    </div>
  );
};

export default InputTabs;
