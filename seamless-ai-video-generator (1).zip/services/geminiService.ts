
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { InputType } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      if (typeof reader.result !== 'string') {
        return reject(new Error('Failed to read file as data URL.'));
      }
      resolve(reader.result.split(',')[1]);
    };
    reader.onerror = (error) => reject(error);
  });
};

const getPrompts = (type: InputType, text: string, fileName?: string) => {
    let descriptionPrompt: string;
    let imagePrompt: string;

    const baseInstruction = "You are a visionary film director. Based on the provided input, generate a creative and detailed shot-by-shot description for a short, animated video. Make it feel cinematic. The description should be structured with scene numbers, camera directions, and action descriptions.";

    switch(type) {
        case InputType.IMAGE:
        case InputType.MODEL:
            descriptionPrompt = `${baseInstruction}\n\nThe input is an image that serves as a keyframe or inspiration. The model file provided is represented as an image. Expand upon the scene, characters, or mood shown.`;
            imagePrompt = "A cinematic, high-quality, photorealistic poster image that is a creative reimagining or continuation of the provided scene.";
            break;
        case InputType.AUDIO:
            descriptionPrompt = `${baseInstruction}\n\nThe input is an audio file named "${fileName}". Generate a video concept that visually represents the mood, rhythm, and story implied by the audio.`;
            imagePrompt = `A cinematic, high-quality, photorealistic poster image for a music video or short film inspired by an audio piece. The mood is ${text || 'dynamic and emotional'}.`; // Use text as a mood descriptor if provided
            break;
        case InputType.SCRIPT:
            descriptionPrompt = `You are a visionary film director. Analyze the following script and generate a detailed shot-by-shot visualization, including camera angles, character actions, and environmental details to bring it to life as a short animated video.\n\nScript:\n"""\n${text}\n"""`;
            imagePrompt = `A cinematic, high-quality, photorealistic poster image for a film based on this script summary: "${text.substring(0, 150)}..."`;
            break;
        case InputType.TEXT:
        default:
            descriptionPrompt = `${baseInstruction}\n\nConcept: "${text}"`;
            imagePrompt = `A cinematic, high-quality, photorealistic poster image for a film based on this idea: "${text}"`;
            break;
    }
    return { descriptionPrompt, imagePrompt };
}


export const generateVideoConcept = async (
    inputType: InputType,
    textData: string,
    fileData: File | null
): Promise<{ description: string; imageUrl: string }> => {

    try {
        const { descriptionPrompt, imagePrompt } = getPrompts(inputType, textData, fileData?.name);

        let textGenerationPromise: Promise<GenerateContentResponse>;

        if (inputType === InputType.IMAGE || inputType === InputType.MODEL) {
            if (!fileData) throw new Error("Image or Model file is required.");
            const base64Data = await fileToBase64(fileData);
            const imagePart = {
                inlineData: { mimeType: fileData.type, data: base64Data },
            };
            textGenerationPromise = ai.models.generateContent({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: { parts: [{ text: descriptionPrompt }, imagePart] },
            });
        } else {
            textGenerationPromise = ai.models.generateContent({
                model: 'gemini-2.5-flash-preview-04-17',
                contents: descriptionPrompt,
            });
        }
        
        const imageGenerationPromise = ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: imagePrompt,
            config: { numberOfImages: 1, outputMimeType: 'image/jpeg' },
        });

        const [textResponse, imageResponse] = await Promise.all([textGenerationPromise, imageGenerationPromise]);
        
        const description = textResponse.text;
        const base64ImageBytes = imageResponse.generatedImages[0].image.imageBytes;
        const imageUrl = `data:image/jpeg;base64,${base64ImageBytes}`;

        if (!description || !imageUrl) {
            throw new Error("Failed to generate a complete concept. The API returned partial data.");
        }

        return { description, imageUrl };

    } catch(error) {
        console.error("Error generating video concept:", error);
        if (error instanceof Error) {
            throw new Error(`An error occurred with the AI service: ${error.message}`);
        }
        throw new Error("An unknown error occurred while generating the video concept.");
    }
};
